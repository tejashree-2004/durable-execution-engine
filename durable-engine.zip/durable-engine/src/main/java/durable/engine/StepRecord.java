package durable.engine;

public class StepRecord {
    public String workflowId;
    public String stepKey;
    public String status;
    public String output;
}

